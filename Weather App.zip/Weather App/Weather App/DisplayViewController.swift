//
//  DisplayViewController.swift
//  Weather App
//
//  Created by sanchan Mac Book on 12/09/20.
//  Copyright © 2020 Peafowl Inc. All rights reserved.
//

import UIKit

class DisplayViewController: UIViewController {

    @IBOutlet weak var countryLabel: UILabel!
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var tempLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var minTempLabel: UILabel!
    @IBOutlet weak var maxTempLabel: UILabel!
    
    var country: String?
    var city: String?
    var temp: Double?
    var descp: String?
    var minTemp: Double?
    var maxTemp: Double?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        countryLabel.text = country
        cityLabel.text = city
        if let trim = temp {
            let temperatureInCelsius = trim - 273.15
            self.tempLabel.text = String(format: "Temp %.0f C", temperatureInCelsius)
        }
        
        if let trim = minTemp {
            let temperatureInCelsius = trim - 273.15
            self.minTempLabel.text = String(format: "Min Temp %.0f C", temperatureInCelsius)
        }
        
        if let trim = maxTemp {
            let temperatureInCelsius = trim - 273.15
            self.maxTempLabel.text = String(format: "Max Temp %.0f C", temperatureInCelsius)
        }
        
        descriptionLabel.text = descp

        // Do any additional setup after loading the view.
    }
    

}
