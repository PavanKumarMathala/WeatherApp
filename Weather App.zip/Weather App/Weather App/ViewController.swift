//
//  ViewController.swift
//  Weather App
//
//  Created by sanchan Mac Book on 12/09/20.
//  Copyright © 2020 Peafowl Inc. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import Alamofire

class ViewController: UIViewController,CLLocationManagerDelegate,UIGestureRecognizerDelegate {
    
    @IBOutlet weak var mapView: MKMapView!
    let locationManager = CLLocationManager()
    var locationCoordinates: CLLocation?
    
    let details = WeatherObject()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUpLocation()
        let tap = UITapGestureRecognizer(target: self, action: #selector(doubleTapped))
        tap.numberOfTapsRequired = 2
        tap.delegate = self
        mapView.addGestureRecognizer(tap)
                
        
        // Do any additional setup after loading the view.
    }
    
    // Changing location on double tapping
    @objc func doubleTapped(_ sender: UITapGestureRecognizer) {
        let locationInView = sender.location(in: mapView)
        let tappedCoordinate = mapView.convert(locationInView, toCoordinateFrom: mapView)
        self.getWeatherData(lat: tappedCoordinate.latitude, lon: tappedCoordinate.longitude) { (true, error) in
            if let displayPage = self.storyboard?.instantiateViewController(withIdentifier: String(describing: DisplayViewController.self)) as? DisplayViewController
            {
                displayPage.city = self.details.city
                displayPage.country = self.details.country
                displayPage.temp = self.details.temp
                displayPage.minTemp = self.details.minTemp
                displayPage.maxTemp = self.details.maxTemp
                displayPage.descp = self.details.description
                self.navigationController?.pushViewController(displayPage, animated: true)
            }
        }
    }
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        print("Simultaneous gesture recognizer!")
        return true
    }
    
    // Setup Current location
    func setUpLocation() {
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
        locationManager.distanceFilter = kCLDistanceFilterNone
        locationManager.startUpdatingLocation()
        mapView.showsUserLocation = true
    }
    
    // Did Update Locations
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        locationCoordinates = locations.last
        let center = CLLocationCoordinate2D(latitude: locationCoordinates?.coordinate.latitude ?? 0.0, longitude: locationCoordinates?.coordinate.longitude ?? 0.0)
        let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05))
        mapView.setRegion(region, animated: true)
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Error - locationManager: \(error.localizedDescription)")
    }
    
    
    // Getting Weather Deatils from API
    func getWeatherData(lat:Double,lon:Double,completion: @escaping(_ success:Bool?,_ error:Error?) -> Void) {
        let url = "http://api.openweathermap.org/data/2.5/weather?lat=\(lat)&lon=\(lon)&appid=\(apiKey)"
        Alamofire.request(url).responseJSON { response in
            if response != nil {
                if let result = response.result.value {
                    let json = result as? [String:Any]
                    if let descDeatils = json?["weather"] as? [[String:Any]] {
                        self.details.description = descDeatils[0]["description"] as? String
                    }
                    if let tempDetails = json?["main"] as? [String:Any] {
                        self.details.temp = tempDetails["temp"] as? Double
                        self.details.minTemp = tempDetails["temp_min"] as? Double
                        self.details.maxTemp = tempDetails["temp_max"] as? Double
                    }
                    if let countryDetails = json?["sys"] as? [String:Any] {
                        self.details.country = countryDetails["country"] as? String
                    }
                    self.details.city = json?["name"] as? String
                    
                }
                completion(true,nil)
            }
            
        }
    }

}

