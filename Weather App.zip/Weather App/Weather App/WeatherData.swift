//
//  WeatherData.swift
//  Weather App
//
//  Created by sanchan Mac Book on 12/09/20.
//  Copyright © 2020 Peafowl Inc. All rights reserved.
//

import Foundation
import UIKit

let apiKey = "43981d738906371d46448b91ab2c9055"

class WeatherObject {
    var country: String?
    var city: String?
    var temp: Double?
    var minTemp: Double?
    var maxTemp: Double?
    var description: String?
}
